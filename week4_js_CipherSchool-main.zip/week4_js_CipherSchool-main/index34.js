const person = {
    name: "harshit",
    age:"22",
    hobbies:["guitar","sleeping","listening music"]
}