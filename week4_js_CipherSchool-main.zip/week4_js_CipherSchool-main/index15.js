// and or operators

let firstName ="Deepa"
// let age = 22;

// if (firstName[0] == " D"){
//     console.log("your name start with D")
// }

// if (age>18){
//     console.log("your above 18");
// }

if (firstName[0] ==="H" && age>18){
    console.log("Name start with D and above 18");
}else{
    ("inside else")
}
console.log(firstName)