// //for loop in array//
// let fruits = ["apple","mango","orange","banana"];

// // for(let i=0; i<=9; i++){
// //     console.log(i);
// // }
// // console.log(fruits.length);
// // console.log(fruits[0]);
// // console.log(fruits[fruits.length-2]);

// // for(let i=0; i< fruits.length; i++){
// //     console.log(i);
// // }
// let fruits2 = [];

// for(let i=0; i < fruits.length; i++){
//     fruits2.push(fruits[i].toUpperCase());
// }
// console.log(fruits2)

const personalDetails = {
    name:"anyname",
    age:18,
    gender:"male"
}
for(i in personalDetails){
    console.log(personalDetails)
};