//if else condition//

let age = 2;
if (age>=18){
    console.log("User can play ddlc")

}else{
    console.log("User can play mario")
}

let num = 15;

if (num%2===0){
    console.log("even");
}else{
    console.log("odd")
}

