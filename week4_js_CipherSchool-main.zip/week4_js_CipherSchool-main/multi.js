// get multiple element using getelement by class name
// get multiple element using querryselector by id
const navItem = document.getElementsByClassName("nav-item");
// console.log(navItem[1]);
console.log(typeof navItem);