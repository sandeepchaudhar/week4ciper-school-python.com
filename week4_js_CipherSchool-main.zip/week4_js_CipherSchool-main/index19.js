// while loop  
// // 0 to 9
// let i = 1;
// // console.log(i);
// // i++;
// while(i<21){
//     console.log(i);
//     i++;
// }
// console.log(`current value of i is ${i}`);

let num = 1;
while(num%50){
    console.log(num);
    num++;
}
console.log(`current value of num is ${num}`)