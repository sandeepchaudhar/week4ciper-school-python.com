// let keyword

// let firstName = "Deepa"
// console.log(firstName);

let firstName = 'Deepa'
// console.log(firstName[3])

console.log(firstName.length);
console.log(firstName[2]);
// console.log(firstName[firstName.length-2]);
let secondName = 'Jaaaanu'
console.log(secondName.length)


