// select  element using document


// const mainheading = document.getElementById("main-heading");

// select id element using query selector
// const mainheading = document.querySelector("#main-heading");
// console.log(mainHeading)


// select class element
const header = document.querySelector(".header");
console.log(header)
// ek hi class alg alg element ka hum likh skte hai
const navItem = document.querySelector(".navItem")
console.log(navItem);