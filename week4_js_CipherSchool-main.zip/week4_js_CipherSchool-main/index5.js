// console.log(firstName.length);



let firstName = "Deepa";
let newString = firstName.trim();
console.log(newString)
console.log(newString.length);
console.log(firstName.toLowerCase());
// console.log(firstName);

// start indexed
// end index

// let newString = firstName .slice()
// console.log(newString);




