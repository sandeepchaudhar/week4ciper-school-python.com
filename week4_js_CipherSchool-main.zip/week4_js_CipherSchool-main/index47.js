//block scope
// {
// let firstName = "harshit";
// console.log(firstName);
// }

// {
//     let firstName = "deepa"
//     console.log(firstName)
// }

// {
//     let firstName = "garima"
//     console.log(firstName)
// }

// {
//     var firstName = "deepa"
// }
// console.log(firstName)

if (true){
    var firstName = "nupur";
    console.log(firstName);

}
console.log(firstName);