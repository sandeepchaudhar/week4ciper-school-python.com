// intro to arrays
//refrence type//

// let fruits = ["apple","mango","orange"];
// console.log(fruits);

let fruits = ["apple","mango","grapes"];
// console.log(fruits);
// fruits[1] = "banana";
// console.log(fruits);

console.log(typeof fruits);
console.log(Array.isArray(fruits));