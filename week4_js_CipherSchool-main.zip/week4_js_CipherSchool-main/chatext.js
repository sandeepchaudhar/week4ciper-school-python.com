// change text
const mainHeading = document.getElementById("main-heading")
console.log(mainHeading.textContent)
mainHeading.textContent = "This is something else";
console.log(mainHeading.textContent)