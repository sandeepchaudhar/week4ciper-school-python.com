// let age = 1;
// let drink;


// if (age>=5){
//      drink = "coffee";

// }else{
//     drink ="milk";
// }
// console.log(drink);


let age = 1;
let drink = age >= 9 ? "coffee " : "milk";
console.log(drink)

