// for of loop
const fruits =["apple","mango","grapes"];

for(let fruit of fruits){
    console.log(fruits.toUpperCase());
}
console.log(fruits2)
 