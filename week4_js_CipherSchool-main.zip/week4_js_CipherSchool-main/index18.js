// switch statement

// let day = 3;

// if (day == 0){
//     console.log("sunday");
// }
// else if(day == 1){
//     console.log("Monday")
// }
// else if(day == 2){
//     console.log("Tuesday")
// }
// else if(day == 3){
//     console.log("Wednesday")
// }
// else if(day == 4){
//     console.log("Thursday")
// }
// else if(day == 5){
//     console.log("friday")
// }
// else if(day == 6){
//     console.log("Saturday")
// }
// else{
//     console.log("Invalid")
// }

let day = 0;
switch (day){
    case 0:
        console.log("Sunday");
    case 1:
        console.log("Monday");
    case 2:
        console.log("Tuesday");
    case 3:
        console.log("Wednesday");
    case 4:
        console.log("Thursday");
    case 5:
        console.log("Friday");
    case 6:
        console.log("Saturday");
    default:
        console.log("Invalid Day")
}

let month = 0
switch(month){
    case 0 :
        console.log('January')
    case 1 :
        console.log('Feb')
    case 2 :
        console.log('March')
    case 3 :
        console.log('Aprill')
    case 4 :
        console.log('May')
    case 5 :
        console.log('June')
    case 6 :
        console.log('July')
    case 7 :
        console.log('August')
    case 8 :
        console.log('September')
    case 9 :
        console.log('October')
    case 10 :
        console.log('November')
    case 11 :
        console.log('December')
    default:
        console.log("Invalid month")    
}