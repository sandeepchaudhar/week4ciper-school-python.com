// change the style
const mainHeading = document.querySelector("div.headline h2");
mainHeading.style.color = "red";
mainHeading.style.border = "red";
mainHeading.style.backgroundColor = "2px solid red";