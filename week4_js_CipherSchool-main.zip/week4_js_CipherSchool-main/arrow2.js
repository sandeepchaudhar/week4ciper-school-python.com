// const singHappyBirthday = function(){
//     console.log("happy birthdat to you....")
// }
const singHappyBirthday = () => {
    // console.log("happy birthdat to you....");    
}
singHappyBirthday();

// const sumOfThreeNumber = function(number1, number2, number3){
//     return number1 + number2 + number3;
// }
const sumOfThreeNumber = (number1, number2, number3) => {
    return number1 + number2 + number3;
}
const ans = sumOfThreeNumber(2,3,4);
console.log(ans);

const isEven = (number) => {
    return number % 2 ===0;
}
console.log(isEven(4));

// const isEven = number => number % 2 ===0;



// const isEven = function(number){
//     return number % 2 ===0;
// }
