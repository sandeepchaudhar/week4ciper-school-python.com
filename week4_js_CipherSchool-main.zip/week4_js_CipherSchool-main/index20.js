// while loop example

let num = 10;
// let total = 0;
// let i =0;
// // while(total<=10){
// //     console.log(total);
// //     total++;
// // }

// while(i<=10){
//     total = total + i;
//     i++;
// }
// console.log(total);

let total = (num*(num+1))/2;
console.log(total);