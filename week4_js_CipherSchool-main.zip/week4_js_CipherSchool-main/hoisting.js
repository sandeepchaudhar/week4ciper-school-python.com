// hoisting
// hello();
// function hello(){
//     console.log("hello world")
// }

