let age = 17;
let firstName = "deepa";
  
let aboutMe = `may name is ${firstName} and my age is ${age}` ;
console.log(aboutMe)