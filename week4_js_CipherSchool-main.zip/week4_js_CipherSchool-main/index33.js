const person = {
    name: "harshit",
    age:"22",
    hobbies:["guitar","sleeping","listening music"]
}
console.log(person);
console.log(person["name"]);
console.log(person["age"]);
console.log(person["hobbies"]);
