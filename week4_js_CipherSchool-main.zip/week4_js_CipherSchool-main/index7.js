// string concatination

// let string1 = "Deepa"
// let string2 = "Anand"
let string1 = "22"
 let string2 = "21"
 let string3 = "21"
 let string4 = "21"
 let string5 = "21"
 let firstName = +string1 +  + string2 + + string3 + + string4 + + string5;
 console.log(firstName);