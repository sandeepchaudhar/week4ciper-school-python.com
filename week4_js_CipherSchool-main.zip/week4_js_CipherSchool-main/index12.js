//truthy and falsy value//
//truthy
//abc
//1 -1
let firstName = null;

if (firstName){
    console.log(firstName);

}else{
    console.log("firstName is kindly empty")
}