// declare constant
 const pi = 3.14;

 console.log(pi*2*2)