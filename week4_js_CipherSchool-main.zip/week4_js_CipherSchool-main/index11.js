//booleans & operation//
let num1 = "5";
let num2 = 5;
// console.log(num1<num2);

// ==vs==//
// console.log(num1===num2);

// != vs

// console.log(num1 != num2);

let yourName = prompt("enter your name: ")
console.log(yourName)
alert(`your name is ${yourName}`)

let MyName = prompt("enter your name: ")
console.log(MyName)
alert(`My name is ${MyName}`)
