// declare a variable
var firstName = 'Harshit';

// use a variable
console.log(firstName);

// change value
const firstname = "Mohit"

 
console.log(firstname);


