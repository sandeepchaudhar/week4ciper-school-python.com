// let firstName;
// firstName = "deepa"
// console.log(typeof firstName);
// console.log(typeof firstName, firstName);


// let myVariable = null;
// console.log(myVariable);
// myVariable = " deepa";
// console.log(myVariable, typeof myVariable);

console.log(typeof null);

let myNumber = BigInt(200);
let sameMynumber = 500n;
console.log(myNumber + sameMynumber);