// if
// else if
// else if
// else if
// else if
// let tempInDegree = 20 ;
let tempInDegree =- 30;
// let tempInDegree = 20 ;

if (tempInDegree < 0){
    console.log("extremely cold otside")
}else if (tempInDegree < 16){
    console.log("It is cold outside")
}

else if (tempInDegree < 25){
    console.log("wheathwe is okay")
}else if (tempInDegree < 35){
        console.log("turn on AC")
}
else if (tempInDegree < 45){
    console.log("lets go fore swim")
}
else{
    console.log("too hot!!");
}
