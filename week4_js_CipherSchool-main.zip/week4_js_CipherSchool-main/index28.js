// use const gor creating array//
// const pi = 3.14;
// pi = 12;
// console.log(pi);

const fruits = ["apple", "mango"];
fruits.push("banana");
console.log(fruits);