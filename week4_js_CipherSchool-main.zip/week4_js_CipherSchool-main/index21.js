// intro to for loop
// print 0 to 9
for(let i = 1; i<=9; i++){
    console.log(i);
}
console.log("value of i is ",i);


for(var i = 1; i<=9; i++){
    console.log(i);
}
console.log("value of i is ",i);

for(var j = 0; j<=12; j++){
    console.log(j);
}