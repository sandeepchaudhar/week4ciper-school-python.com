// // types of operator

let age = 17;
let firstName = "Deepa"
console.log(typeof age)

console.log(typeof (age + " "));

let myString =+"17";
console.log(typeof myString)

// let age = 17;
// age = Number(age);
// console.log(typeof age);

