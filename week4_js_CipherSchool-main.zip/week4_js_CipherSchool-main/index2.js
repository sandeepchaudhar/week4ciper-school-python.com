// for values
var value1 = 10;
console.log(value1**2);

// you can use only underscore _ or dollar
// first_name(valid)

// you cannot start with any number or space 