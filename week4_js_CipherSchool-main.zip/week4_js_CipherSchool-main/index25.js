//primitive refrence type//
// let num1 = 6;
// let num2 = num1;
// console.log("value of num1 is", num1);
// console.log("value of num2 is", num1);
// num1++;
// console.log("after incresing num1")
// console.log("value of num1 is", num1);
// console.log("value of num2 is", num1);

let array1 = ["item1","item2"];
let array2 = array1;
// console.log("array1", array1);
// console.log("array2", array2);
// array1.push("items3");
// console.log("after pushing element to array 1");
// console.log("aaray1", array1);
// console.log("aaray2", array2);
console.log(array1===array2);

